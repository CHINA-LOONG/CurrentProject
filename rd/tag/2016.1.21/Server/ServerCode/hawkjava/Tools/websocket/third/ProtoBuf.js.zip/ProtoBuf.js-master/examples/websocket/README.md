ProtoBuf.js WebSocket example
=============================
This example shows how to use binary websockets to transfer protocol buffers.

Instructions
------------
1. Set up dependencies: `npm install`
2. Run: `node server.js`
3. Open [http://localhost:8080/](http://localhost:8080/) in a recent browser
